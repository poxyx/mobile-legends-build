<style type="text/css">
    /* USER PROFILE PAGE */
 .card {
    margin-top: 20px;
    padding: 30px;
    background-color: rgba(214, 224, 226, 0.2);
    -webkit-border-top-left-radius:5px;
    -moz-border-top-left-radius:5px;
    border-top-left-radius:5px;
    -webkit-border-top-right-radius:5px;
    -moz-border-top-right-radius:5px;
    border-top-right-radius:5px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    border-radius: 0px;
}
.card.hovercard {
    position: relative;
    padding-top: 0;
    overflow: hidden;
    text-align: center;
    background-color: #fff;
    background-color: rgba(255, 255, 255, 1);
}
.card.hovercard .card-background {
    height: 130px;
}
.card-background img {
    -webkit-filter: blur(5px);
    -moz-filter: blur(5px);
    -o-filter: blur(5px);
    -ms-filter: blur(5px);
    filter: blur(5px);
    margin-left: -100px;
    margin-top: -200px;
    min-width: 130%;
}
.card.hovercard .useravatar {
    position: absolute;
    top: 15px;
    left: 0;
    right: 0;
}
.card.hovercard .useravatar img {
    width: 100px;
    height: 100px;
    max-width: 100px;
    max-height: 100px;
    -webkit-border-radius: 50%;
    -moz-border-radius: 50%;
    border-radius: 50%;
    border: 5px solid rgba(255, 255, 255, 0.5);
}
.card.hovercard .card-info {
    position: absolute;
    bottom: 14px;
    left: 0;
    right: 0;
}
.card.hovercard .card-info .card-title {
    padding:0 5px;
    font-size: 25px;
    line-height: 1;
    color: #fff;
    background-color: rgba(255, 255, 255, 0.1);
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;

}
.card.hovercard .card-info {
    overflow: hidden;
    font-size: 12px;
    line-height: 20px;
    color: #737373;
    text-overflow: ellipsis;
}
.card.hovercard .bottom {
    padding: 0 20px;
    margin-bottom: 17px;
}
.btn-pref .btn {
    -webkit-border-radius:0 !important;
}

  .bg {
        -webkit-background-size: cover;
        -moz-background-size: cover;
        -o-background-size: cover;
        background-size: cover;

    }

    .bg:before {
      content: "";
      position: fixed;
      left: 0;
      right: 0;
      z-index: -1;

      display: block;
      background-image: url('https://i.ytimg.com/vi/zX_7r29aCzM/maxresdefault.jpg');
      background-size:cover;
      width: 100%;
      height: 100%;

      -webkit-filter: blur(5px);
      -moz-filter: blur(5px);
      -o-filter: blur(5px);
      -ms-filter: blur(5px);
      filter: blur(5px);
    }

    .tab-content,.well  {

        background-color: #f7f7f7;
        color: #000
    }

     p {
        text-align: justify;
     }

     .jumbotron,.info{

        border-radius: 0px !important;
        background-color: #fff;
        padding: 5px;
        padding-left: 0px;
        padding-right: 0px;
        -webkit-box-shadow: 1px 1px 5px 0 rgba(0,0,0,.15);
        box-shadow: 1px 1px 5px 0 rgba(0,0,0,.15);
        border: 3px dashed #ccc;
     }

     #tab2 .row .col-xs-4 .jumbotron h6 {

        color: #3b5998;
        font-size: 10px;
        
     }

       #tab2 .row .col-xs-4 .jumbotron h5 {

       font-size: 12px;
     }

     #ex1Slider .slider-selection {
    background: #BABABA;
}

.dotted {
    -webkit-box-shadow: 1px 1px 5px 0 rgba(0,0,0,.15);
        box-shadow: 1px 1px 5px 0 rgba(0,0,0,.15);
        border: 3px dashed #ccc;
}

.info {
    padding:8px;
}

#snackbar {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 17px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}

.item_name {

    font-weight: bold;
}

.well .title {

    color: #fff;
    font-weight: bold;
    background-color: #4B77BE;
}

.physical {
    color:red;
    font-weight: bold;
}

.magic {
    color:blue;
    font-weight: bold;
}

.dmg_info {

    color: grey;
}

</style>

<?php foreach($hero as $row):?>

<?php

$useragent=$_SERVER['HTTP_USER_AGENT'];

if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))) {

        echo '<div class="container-fluid">';

    }else {

        echo '<div class="container">';

    }


?>

    <div class="bg row">
        <div class="col-lg-12 col-sm-12">
    <div class="card hovercard">
        <br>
        <div class="card-background">
            <img class="card-bkimg" alt="" src="http://mobilelegendscounters.com/public/img/<?=strtolower($row['HERO_NAME']);?>.jpg">
            <!-- http://lorempixel.com/850/280/people/9/ -->
        </div>
        <div class="useravatar">
            <img alt="" src="<?=$row['HERO_PHOTO'];?>">
        </div>
        <br>
        <div class="card-info"> 
            <span class="card-title"><?=$row['HERO_NAME'];?></span>
            <br><br>
        </div>
    </div>
    <div class="btn-pref btn-group btn-group-justified btn-group-lg" role="group" aria-label="...">

    <script type="text/javascript">
        
        isActive = function(id){

            var className = $("#" + id).attr('class')
      
            $("#" + id).removeClass("btn btn-default").addClass("btn btn-primary");
              
        }

    </script>

        <div class="btn-group" role="group">
            <button type="button" id="builder" class="btn btn-default" href="#tab1" data-toggle="tab" onclick="isActive('builder')"><span class="glyphicon glyphicon-star" aria-hidden="true"></span>
                <div class="hidden-xs">BUILDER</div>
            </button>
        </div>

        <div class="btn-group" role="group">
            <button type="button" id="stats" class="btn btn-default" href="#tab2" data-toggle="tab" onclick="isActive('stats')"><span class="glyphicon glyphicon-heart" aria-hidden="true"></span>
                <div class="hidden-xs">ATTRIBUTES</div>
            </button>
        </div>

        <div class="btn-group" role="group">
            <button type="button" id="skill" class="btn btn-default" href="#tab3" data-toggle="tab" onclick="isActive('skill')"><span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                <div class="hidden-xs">SKILL</div>
            </button>
        </div>

    </div>

    <script type="text/javascript">

        var slot1   = false
        var slot2   = false
        var slot3   = false
        var slot4   = false 
        var slot5   = false 
        var slot6   = false
        var emblem  = false
        var t1      = false 
        var t2      = false

        function getSlot1()
        {

            slot1 = true
            slot2 = false
            slot3 = false
            slot4 = false
            slot5 = false
            slot6 = false
        }

        function getSlot2()
        {

            slot2 = true
            slot1 = false
            slot3 = false
            slot4 = false
            slot5 = false
            slot6 = false
        }

         function getSlot3()
         {

            slot3 = true
            slot1 = false
            slot2 = false
            slot4 = false
            slot5 = false
            slot6 = false
        }

         function getSlot4()
         {

            slot4 = true
            slot1 = false
            slot2 = false
            slot3 = false
            slot5 = false
            slot6 = false
        }

         function getSlot5()
         {

            slot5 = true
            slot1 = false
            slot2 = false
            slot3 = false
            slot4 = false
            slot6 = false
        }

         function getSlot6()
         {

            slot6 = true
            slot1 = false
            slot2 = false
            slot3 = false
            slot4 = false
            slot5 = false
        }

        function getEmblem()
        {
            emblem = true
            t1     = false 
            t2     = false
        }

        function getTalent1()
        {
            emblem = false
            t1     = true
            t2     = false
        }

        function getTalent2()
        {
            emblem = false
            t1     = false 
            t2     = true
        }

        function addItem(id,img_url,name){
 
            if(slot1 == true) {

                $('#slot1').attr('src', img_url )
                $('#slot1_name').html(name)
                $('input[name=slot1]').val(id);

            } else if (slot2 == true) {

                $('#slot2').attr('src', img_url )
                $('#slot2_name').html(name)
                $('input[name=slot2]').val(id);

            } else if (slot3 == true) {

                $('#slot3').attr('src', img_url )
                $('#slot3_name').html(name)
                $('input[name=slot3]').val(id);

            } else if (slot4 == true) {

                $('#slot4').attr('src', img_url )
                $('#slot4_name').html(name)
                $('input[name=slot4]').val(id);

            } else if (slot5 == true) {

                $('#slot5').attr('src', img_url )
                $('#slot5_name').html(name)
                $('input[name=slot5]').val(id);

            } else if (slot6 == true) {

                $('#slot6').attr('src', img_url )
                $('#slot6_name').html(name)
                $('input[name=slot6]').val(id);

            } else {

                // 
            }

            // console.log($('input[name=slot1]').val())
            $('.close').click()
            
        }

         function addEmblem(id,img_url) {

            if (emblem == true) {

                $('#emblem').attr('src', img_url )
                $('input[name=emblem]').val(id);

                } else if (t1 == true) {

                $('#talent1').attr('src', img_url )
                $('input[name=talent1]').val(id);

                } else if (t2 == true) {

                $('#talent2').attr('src', img_url )
                $('input[name=talent2]').val(id);


                } else {

                    // 
                }

                $('.close').click()
        }

    </script>

    <div class="well">
      <div class="tab-content">
        <div class="tab-pane fade in active" id="tab1" style="min-height: 900px">

            <div class="row">
                <div class="col-xs-6">
                    <?php

                        if($row['PATCH'] != '1.3.06') {
                            $c = "label label-danger";
                        } else {
                            $c = "label label-success";
                        }

                         if($row['STATUS'] != 'STATS UPDATED' && $row['STATUS'] != 'TESTED') {
                            $x = "label label-danger";
                        } else {
                            $x = "label label-success";
                        }
                    ?>

                    <div class="row">
                        <div class="col-xs-6">
                            <center><span class="<?=$c;?>">PATCH  VERSION (ORIGINAL SERVER) : <?=$row['PATCH'];?></span></center>
                        </div>
                        <div class="col-xs-6">
                             <span class="<?=$x;?>">STATUS : <?=$row['STATUS'];?></span>
                        </div> 
                    </div>
                     
                    
                </div>
                <div class="col-xs-6">
                    
                </div>
            </div>

            <div class="row">

                 <center><h2 class="well title"> HERO / SKILL </h2></center>
                 <hr>

                 <div class="col-xs-12">

                 <div class=" dotted col-xs-3">
                    <span class="label label-primary"> LEVEL </span>
                    <br><br>
                    <center> 
                        <img id="#" src="<?=$row['HERO_PHOTO'];?>" width="100px" height="100px" class="img-circle"> 
                    <br><br>

                     <select class="calculate form-control" id="hero_level">
                        <option value="0" disabled selected>Level</option>
                           <?php $x = 0; while ( $x <= 14) {;?>
                            <option value="<?=$x;?>"> LEVEL : <?=$x + 1;?> </option>
                           <?php $x++; };?>
                     </select>

                    </center>
                    <br>
                 </div>

                <?php $c = 1; foreach ($skill as $s):

                        if($s['SKILL_TYPE'] == "ACTIVE") {

                ?>

                 <div class=" dotted col-xs-3">

                    <span class="label label-warning"> <?=$s['SKILL_NAME'];?> </span>
                    <br><br>
                    <center> 
                        <img id="" src="<?=$s['SKILL_PHOTO'];?>" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden" value="10" name="talent1">
                    <br><br>
                     <select class="calculate form-control" id="skill_<?=$c++;?>_level">
                        <option value="0" disabled selected>Level</option>
                           <?php $x = 0; while ( $x <= 5) {;?>
                            <option value="<?=$x;?>"> LEVEL : <?=$x + 1;?> </option>
                           <?php $x++; };?>
                     </select>

                    </center>
                    <br>
                 </div>
                
                <?php } endforeach ;?>

                 </div>

             </div>
           <br><br>
            <div class="row">

            <center><h2 class="well title">ITEM</h2></center>
            <hr>

            <div class="col-xs-8"> 
                              
                 <div class="dotted col-xs-4">
                  <small><span class="label label-info" id="slot1_name"> SLOT 1 </span></small>
                    <br>
                    <center> 
                     <a href="javascript:void(0)" class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot1()">
                        <img id="slot1" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden" value="95"  name="slot1">
                    </a>
                    </center>  
                    <br>               
                 </div>
                 <div class="dotted col-xs-4">
                    <small><span class="label label-info" id="slot2_name"> SLOT 2 </span></small>
                    <br>
                    <center> 
                     <a href="javascript:void(0)" class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot2()">
                        <img id="slot2" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden" value="95"  name="slot2">
                    </a>
                    </center>
                    <br>
                 </div>
                 <div class="dotted col-xs-4">
                    <small><span class="label label-info" id="slot3_name"> SLOT 3 </span></small>
                    <br>
                    <center> 
                     <a href="javascript:void(0)"class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot3()">
                        <img id="slot3" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden" value="95"  name="slot3">
                    </a>
                    </center>
                    <br>
                 </div>

             <br>

                 <div class="dotted col-xs-4">
                    <small><span class="label label-info" id="slot4_name"> SLOT 4 </span></small>
                    <br>
                    <center> 
                    <a href="javascript:void(0)" class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot4()">
                        <img id="slot4" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden"  value="95" name="slot4">
                    </a>
                    </center>
                    <br>
                 </div>
                 <div class="dotted col-xs-4">
                    <small><span class="label label-info" id="slot5_name"> SLOT 5 </span></small>
                    <br>
                    <center> 
                     <a href="javascript:void(0)" class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot5()">
                        <img id="slot5" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden"  value="95" name="slot5">
                    </a>
                    </center>
                    <br>
                 </div>
                 <div class="dotted col-xs-4">
                    <small><span class="label label-info" id="slot6_name"> SLOT 6 </span></small>
                    <br>
                    <center> 
                     <a href="javascript:void(0)"class="get_item" data-toggle="modal" data-target="#item" onclick="getSlot6()">
                        <img id="slot6" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="100px" height="100px" class="img-circle"> 
                        <input type="hidden"  value="95" name="slot6">
                    </a>
                    </center>
                    <br>
                 </div>
             </div>

            <!--  <div class="col-xs-1">
             </div>
 -->
             <div class="col-xs-4">

             <!-- <center><h5>TOTAL ADDED ATTRIBUTES </h5></center> -->
                <span id="item_total_cost" style="color: #F5D76E"></span>
                <span id="item_added_attack" ></span>
                <span id="item_added_hp"></span>
                <span id="item_added_mana"></span>
                <span id="item_added_armor"></span>
                <span id="item_added_magic_res"></span>
                <span id="item_added_hp_regen"></span>
                <span id="item_added_mana_regen"></span>
                <span id="item_added_atk_speed_per"></span>
                <span id="item_added_atk_speed_fix"></span>
                <span id="item_added_lifesteal"></span>
                <span id="item_added_magic_power"></span>
                <span id="item_added_spell_vamp"></span>
                <span id="item_added_magic_pen_fix"></span>
                <span id="item_added_move_speed_fix"></span>
                <span id="item_added_move_speed_per"></span>
                <span id="item_added_cd_reduction"></span>
                <span id="item_added_crit_chance"></span>
                <span id="item_added_crit_reduction"></span>
                <span id="item_added_resilience"></span>

             </div>

             </div>

             <hr>

             <div class="row">

                 <center><h2 class="well title">EMBLEMS / TALENT </h2></center>
                 <hr>

                 <div class="col-xs-8">

                 <div class=" dotted col-xs-4">
                    <span class="label label-primary"> EMBLEM </span>
                    <br><br>
                    <center> 
                     <a href="javascript:void(0)"class="get_emblem" data-toggle="modal" data-target="#talent" onclick="getEmblem()">
                        <img id="emblem" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="70px" height="70px" class="img-circle"> 
                        <input type="hidden" value="10" name="emblem">
                    </a>
                    <br><br>
                     <select class="calculate form-control" id="emblem_level">
                        <option value="0" disabled selected>Level</option>
                           <?php $x = 0; while ( $x <= 60) {;?>
                            <option value="<?=$x;?>"> LEVEL : <?=$x;?> </option>
                           <?php $x++; };?>
                     </select>

                    </center>
                    <br>
                 </div>

                 <div class=" dotted col-xs-4">
                    <span class="label label-primary"> TALENT T1 </span>
                    <br><br>
                    <center> 
                     <a href="javascript:void(0)" class="get_talent1" data-toggle="modal" data-target="#talent" onclick="getTalent1()">
                        <img id="talent1" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="70px" height="70px" class="img-circle"> 
                        <input type="hidden" value="55" name="talent1">
                    </a>
                    <br><br>
                     <select class="calculate form-control" id="talent1_level">
                        <option value="0" disabled selected>Level</option>
                           <?php $x = 1; while ( $x <= 3) {;?>
                            <option value="<?=$x;?>"> LEVEL : <?=$x;?> </option>
                           <?php $x++; };?>
                     </select>

                    </center>
                    <br>
                 </div>

                  <div class=" dotted col-xs-4">
                    <span class="label label-primary"> TALENT T2 </span>
                    <br><br>
                    <center> 
                     <a href="javascript:void(0)" class="get_talent2" data-toggle="modal" data-target="#talent" onclick="getTalent2()">
                        <img id="talent2" src="https://www.gmatamsterdam.com/wp-content/uploads/2015/07/vraagteken-in-cirkels_318-57711.jpg" width="70px" height="70px" class="img-circle"> 
                        <input type="hidden" value="55" name="talent2">
                    </a>
                    <br><br>
                     <select class="calculate form-control" id="talent2_level">
                        <option value="0" disabled selected>Level</option>
                           <?php $x = 1; while ( $x <= 3) {;?>
                            <option value="<?=$x;?>"> LEVEL : <?=$x;?> </option>
                           <?php $x++; };?>
                     </select>

                    </center>
                    <br>
                 </div>
                 </div>

                 <div class="col-xs-4">
                 <!-- <center><h5>TOTAL ADDED ATTRIBUTES </h5></center> -->
                 <hr>

                 </div>

             </div>

             <hr>

        </div>

        <div class="tab-pane fade in" id="tab2" style="min-height: 900px">
            <div class="row">
                <br>
                <!-- <div class="col-xs-12">
                    <br>
                        <center>
                            <input id="level_slider" data-slider-id='ex1Slider' type="text" data-slider-min="1" data-slider-max="15" data-slider-step="1" data-slider-value="1"/>
                        </center>
                    <br>
                </div> -->

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>PHYSICAL ATTACK</b></center></h6>
                        <h5>
                            <center>
                                <b> 
                                    <span id="total_attack" class="green"><b><?=$row['HERO_PHYSICAL_ATK'];?></b></span>
                                    ( 
                                    <span id="level_attack"><?=$row['HERO_PHYSICAL_ATK'];?></span> + 
                                    <span id="added_attack" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>HIT POINTS</b></center></h6>                   
                         <h5>
                            <center>
                                <b> 
                                    <span id="total_hp" class="green"><b><?=$row['HERO_HP'];?></b></span>
                                    ( 
                                    <span id="level_hp"><?=$row['HERO_HP'];?></span> + 
                                    <span id="added_hp" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MANA</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_mana" class="green"><b><?=$row['HERO_MANA'];?></b></span>
                                    ( 
                                    <span id="level_mana"><?=$row['HERO_MANA'];?></span> + 
                                    <span id="added_mana" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>ARMOR</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_armor" class="green"><b><?=$row['HERO_ARMOR'];?></b></span>
                                    ( 
                                    <span id="level_armor"><?=$row['HERO_ARMOR'];?></span> + 
                                    <span id="added_armor" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>PHYSICAL PEN</b></center></h6>
                        <h5>
                         <center>
                                <b> 
                                    <span id="total_phy_pen_fix" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_phy_pen_fix">0</span> + 
                                    <span id="added_phy_pen_fix" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>LIFESTEAL</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_lifesteal" class="green">0</b></span>
                                    ( 
                                    <span id="level_lifesteal">0</span> + 
                                    <span id="added_lifesteal" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>HP REGEN</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_hp_regen" class="green"><b><?=$row['HERO_HP_REGEN'];?></b></span>
                                    ( 
                                    <span id="level_hp_regen"><?=$row['HERO_HP_REGEN'];?></span> + 
                                    <span id="added_hp_regen" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MANA REGEN</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_mana_regen" class="green"><b><?=$row['HERO_MANA_REGEN'];?></b></span>
                                    ( 
                                    <span id="level_mana_regen"><?=$row['HERO_MANA_REGEN'];?></span> + 
                                    <span id="added_mana_regen" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>


                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MAGIC POWER</b></center></h6>
                         <h5>
                            <center>
                                <b> 
                                    <span id="total_magic_power" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_magic_power">0</span> + 
                                    <span id="added_magic_power" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>


                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MAGIC RESISTANCE</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_magic_armor" class="green"><b><?=$row['HERO_MAGIC_ARMOR'];?></b></span>
                                    ( 
                                    <span id="level_magic_armor"><?=$row['HERO_MAGIC_ARMOR'];?></span> + 
                                    <span id="added_magic_armor" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MAGIC PEN</b></center></h6>
                        <h5>
                            <center>
                                <b> 
                                    <span id="total_magic_pen_fix" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_magic_pen_fix">0</span> + 
                                    <span id="added_magic_pen_fix" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>SPELL VAMP </b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_spell_vamp" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_spell_vamp">0</span> + 
                                    <span id="added_spell_vamp" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>

                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MOVEMENT SPEED</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_move_speed" class="green"><b><?=$row['HERO_MOVE_SPEED'];?></b></span>
                                    ( 
                                    <span id="level_move_speed"><?=$row['HERO_MOVE_SPEED'];?></span> + 
                                    <span id="added_move_speed" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>


                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>CD REDUCTION</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_cd_reduction" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_cd_reduction">0</span> + 
                                    <span id="added_cd_reduction" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>ATTACK SPEED</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_attack_speed" class="green"><b><?=$row['HERO_ATK_SPEED']/100;?></b></span>
                                    ( 
                                    <span id="level_attack_speed"><?=$row['HERO_ATK_SPEED']/100;?></span> + 
                                    <span id="added_attack_speed" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>CRIT CHANCE</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_crit_chance" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_crit_chance">0</span> + 
                                    <span id="added_crit_chance" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>CRIT REDUCTION</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_crit_reduction" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_crit_reduction">0</span> + 
                                    <span id="added_crit_reduction" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>RESILIENCE</b></center></h6>
                        <h5>
                        <center>
                                <b> 
                                    <span id="total_resilience" class="green"><b>0</b></span>
                                    ( 
                                    <span id="level_resilience">0</span> + 
                                    <span id="added_resilience" class="green">0</span> 
                                    )
                                </b>
                            </center>
                        </h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>DMG TO MONSTER</b></center></h6>
                        <h5 class="green"><center><b><span id="dmg_monster">0</span> %</b></center></h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>CRIT DAMAGE</b></center></h6>
                        <h5 class="green"><center><b><span id="crit_dmg">0</span> %</b></center></h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>HEALING EFFECTS</b></center></h6>
                         <h5 class="green"><center><b><span id="healing_effect">0</span> %</b></center></h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>BATTLE SPELL</b></center></h6>
                        <h5 class="green"><center><b><span id="battle_spell">0</span> %</b></center></h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>MAGIC PEN %</b></center></h6>
                        <h5 class="green"><center><b><span id="mgc_pen_per">0</span> %</b></center></h5>
                    </div>
                </div>

                <div class="col-xs-6 col-md-4">
                    <div class="jumbotron">
                        <h6><center><b>PHYSICAL PEN %</b></center></h6>
                         <h5 class="green"><center><b><span id="phy_pen_per">0</span> %</b></center></h5>
                    </div>
                </div>

            </div>
        </div>

        <div class="tab-pane fade in" id="tab3">
            <br><br>

            <?php  $count = 1; $mana = 1; $cd = 1; foreach($skill as $s):?>

                <div class="row" style="border: 3px dashed #ccc;margin:0px;">
                 <!-- <div class="col-xs-1"></div> -->
                    <div class="col-xs-3">
                        <br><br><br><br>
                        <center><img src="<?=$s['SKILL_PHOTO'];?>" class="img-circle" width="125px" height="125px"></center>
                    </div>
                     <div class="col-xs-8">
                        <br>
                        <span class="label label-info"> <b><?=strtoupper($s['SKILL_TYPE']);?></b></span> <center> <b><?=strtoupper($s['SKILL_NAME']);?></b></center>
                        <hr>
                        <p>
                            <?php 

                            echo 
                             str_replace('Magic','<span class="magic">Magic</span>',
                               str_replace('Physical','<span class="physical">Physical</span>',
                                 str_replace('magic','<span class="magic">Magic</span>',
                                    str_replace('physical','<span class="physical">Physical</span>',
                                      str_replace('magical','<span class="magic">Magic</span>',
                                                   $s['SKILL_DESC'])))));

                            ?>                    
                        </p>

                        <br>

                        <div class="alert alert-info">
                            <center><b><span><small>INITIAL SKILL BASE DAMAGE + ITEMS DAMAGE INFO : </small></b></center>
                            <br>
                            <span id="skill_info_<?=$count++;?>"></span>
                        </div>

                        <hr>
                        <span class="label label-primary" id="skill_mana_<?=$mana++;?>"> <b>Mana cost: <?=strtoupper($s['SKILL_BASE_MANA_COST']);?></b></span>
                        <span class="label label-success" id="skill_cooldown_<?=$cd++;?>"> <b>Cooldown: <?=strtoupper($s['SKILL_BASE_COOLDOWN']);?></b></span>
                        <br><br>
                    </div>
                  <div class="col-xs-1"></div>
                </div>
                <br>
            
            <?php endforeach;?>     
            
        </div>

      </div>
    </div>
    
    </div>
    </div>
    <br>
     <div class="fb-comments" data-href="http://jomkira.com/mlbb/" data-width="100%" data-numposts="5"></div>
</div>

<?php endforeach;?>

<!-- Modal ITEM -->
  <div class="modal fade" id="item" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <ul class="nav nav-tabs">           
              <li class="active"><a data-toggle="tab" href="#attack">ATTACK</a></li>
              <li><a data-toggle="tab" href="#magic">MAGIC</a></li>
              <li><a data-toggle="tab" href="#defense">DEFENSE</a></li>
              <li><a data-toggle="tab" href="#move">MOVEMENT</a></li>
              <li><a data-toggle="tab" href="#jungle">JUNGLE</a></li>
              <li><a data-toggle="tab" href="#basic">BASIC</a></li>
            </ul>

            <div class="tab-content">
              <div id="basic" class="tab-pane fade ">
                 <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "BASIC" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
              <div id="attack" class="tab-pane fade in active">
                <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "ATTACK" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
              <div id="magic" class="tab-pane fade">
                 <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "MAGIC" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
              <div id="defense" class="tab-pane fade">
                 <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "DEFENSE" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
              <div id="move" class="tab-pane fade">
                 <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "MOVEMENT" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
              <div id="jungle" class="tab-pane fade">
                 <br>
                   <div class="row">
                        <?php foreach ($item as $i):

                            if($i['ITEM_CATEGORY'] == "JUNGLE" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addItem(<?=$i['ID'];?>,<?php echo "'".$i['ITEM_PHOTO']."'";?>,<?php echo "'".$i['ITEM_NAME']."'";?>)">
                                <img src="<?=$i['ITEM_PHOTO'];?>" width="100px" height="100px" class="img-circle">
                            </a>
                            <br><br>
                            </div>                        

                        <?php } endforeach;?>
                   </div>
              </div>
            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<!-- Modal EMBLEM -->
  <div class="modal fade" id="talent" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <ul class="nav nav-tabs">           
              <li class="active"><a data-toggle="tab" href="#emblem_0">EMBLEM</a></li>
              <li><a data-toggle="tab" href="#talent_1">TALENT T1</a></li>
              <li><a data-toggle="tab" href="#talent_2">TALENT T2</a></li>
              <!-- <li><a data-toggle="tab" href="#talent_3">TALENT T3</a></li> -->
            </ul>

            <div class="tab-content">
              <div id="emblem_0" class="tab-pane fade in active ">
                 <br>
                   <div class="row">
                        <?php foreach ($emblem as $e):

                            if($e['ID'] != "10" ) {

                        ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addEmblem(<?=$e['ID'];?>,<?php echo "'".$e['EMBLEM_PHOTO']."'";?>)">
                                <center><img src="<?=$e['EMBLEM_PHOTO'];?>" width="70px" height="70px" class="img-circle"></center>
                            </a>
                            <center><b><small><?=$e['EMBLEM_NAME'];?></small></b></center>
                            <br>
                            </div>                        

                         <?php } endforeach;?>
                   </div>
              </div>

              <div id="talent_1" class="tab-pane fade ">
                <br>
                   <div class="row">
                        <?php foreach ($talent_tier_1 as $t): ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addEmblem(<?=$t['ID'];?>,<?php echo "'".$t['EMBLEM_PHOTO']."'";?>)">
                                <center><img src="<?=$t['EMBLEM_PHOTO'];?>" width="70px" height="70px" class="img-circle"></center>
                            </a>
                            
                            <center><b><small>T1 : <?=$t['TALENT_NAME'];?> </small></b></center>
                            <br>
                            </div>                        

                        <?php  endforeach;?>
                   </div>
              </div>

             <div id="talent_2" class="tab-pane fade ">
                <br>
                   <div class="row">
                        <?php foreach ($talent_tier_2 as $t): ?>

                            <div class="col-xs-3 col-md-3">
                            <a href="javascript:void(0)" onclick="addEmblem(<?=$t['ID'];?>,<?php echo "'".$t['EMBLEM_PHOTO']."'";?>)">
                                <center><img src="<?=$t['EMBLEM_PHOTO'];?>" width="70px" height="70px" class="img-circle"></center>
                            </a>
                            
                            <center><b><small> T2 : <?=$t['TALENT_NAME'];?> </small></b></center>
                            <br>
                            </div>                        

                        <?php  endforeach;?>
                   </div>
              </div>
            </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>


<div id="snackbar">ALL HERO ATTRIBUTES/SKILL UPDATED</div>

<?php foreach ($hero as $id): ?>                          
    <input type="hidden" name="hero_id" value="<?=$id['ID'];?>">
<?php  endforeach;?>

<div id="loading"></div>

