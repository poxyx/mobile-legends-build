# Codeigniter Boilerplate  [DISCONTINUED]

A codeigniter Boilerplate to quickly get you up and running with [codeigniter][1] with the best practises applied from [html5boilerplate][2].


Check the WIKI https://github.com/ariok/codeigniter-boilerplate/wiki for more information about Codeigniter-
Boilerplate.


[1]: http://codeigniter.com/
[2]: http://html5boilerplate.com/
